class ItemNotFoundError(Exception):
    pass
