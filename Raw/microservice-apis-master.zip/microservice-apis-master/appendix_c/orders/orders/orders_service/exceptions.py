class OrderNotFoundError(Exception):
    pass


class APIIntegrationError(Exception):
    pass


class InvalidActionError(Exception):
    pass
